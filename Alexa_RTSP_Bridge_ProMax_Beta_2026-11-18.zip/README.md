<p align="center"><img src="images/logo.png" alt="Alexa RTSP Bridge" width="155"></p>
<h1 align="center">Alexa RTSP Bridge · Pro Beta</h1>
<p align="center"><b>RTSP cameras on Alexa / Fire TV, without keeping every transcoder running.</b></p>
<p align="center"><img src="images/firetv_preview.gif" alt="Real Fire TV playback, recorded on the original system" width="780"></p>
<p align="center"><a href="https://github.com/RenanEspinar/Alexa-RTSP-Bridge/blob/main/Alexa_RTSP_Bridge_FireTV_README_1080p.mp4"><b>▶ Watch the real Fire TV video</b></a> · <a href="docs/PRO_MAX.md"><b>Installation & validation</b></a> · <a href="docs/SECURITY.md"><b>Security</b></a></p>

![Status](https://img.shields.io/badge/Version-0.2.0_beta-orange) ![HA](https://img.shields.io/badge/Home_Assistant-Add--on_beta-18BCF2) ![Docker](https://img.shields.io/badge/Docker-Stand--alone-2496ED) ![Python](https://img.shields.io/badge/Python-3.13-3776AB) ![License](https://img.shields.io/badge/License-MIT-green)

## Why this version exists

I started this bridge to get my RTSP cameras working through Alexa on Fire TV. The original version already works with eight cameras on my own Ubuntu server, and the video above comes from that installation. After sharing the project, I wanted to make it easier to install, troubleshoot and run with fewer resources.

**Pro Beta** adds a web dashboard, camera configuration, an optional Home Assistant add-on package and a signed HLS server. It can copy compatible H.264 streams directly into HLS, or transcode when the camera needs it. Each camera is started only when its playlist is requested and stops after the idle timeout.

**Important:** the Fire TV video demonstrates the original deployment, **not this new beta**. The Pro Beta has passed offline tests, including a local synthetic H.264/HLS playback test, but has **not yet passed a clean Docker or HA OS deployment or real Alexa end-to-end verification**. This is a development branch, not a production release.

## What you get

| Component | What it does |
|---|---|
| **Camera dashboard** | Add and edit RTSP cameras, inspect state, capture snapshots and run codec probes. |
| **H.264 copy mode** | Remuxes compatible H.264 Baseline/Main without CPU-intensive re-encoding. |
| **Automatic mode** | Uses `ffprobe` to select H.264 copy or Baseline transcoding. |
| **Independent camera workers** | Starts/stops FFmpeg on HLS playlist activity. No Docker socket required. |
| **Watchdog** | Checks stream freshness and restarts recently requested failed streams with cooldown. |
| **Snapshots** | Captures JPEG images when requested, with a configurable cache. |
| **Signed HLS** | HMAC-SHA256 signing of playlists, TS segments and snapshots with an expiry time. |
| **Two distributions** | Docker Compose for Ubuntu / HA Container; add-on folder for HA OS / Supervised. |

<p align="center"><img src="images/on_demand_flow.gif" alt="FFmpeg on-demand operation" width="780"></p>

```mermaid
flowchart LR
  F[Fire TV / Alexa] --> L[AWS Lambda Smart Home]
  L <--> A[Home Assistant]
  L -->|Signed HLS URL| T[HTTPS / Cloudflare Tunnel]
  T --> S[HLS Gateway]
  S --> W[On-demand FFmpeg]
  C[RTSP camera] --> W
  W --> S
  S --> F
  UI[Private admin dashboard] --> S
```

## Quick start — test host only

For the standalone Docker build, use a **separate test machine**. My working Ubuntu server already uses port 8090, so do not start this container there with default ports.

```bash
git clone --branch feature/pro-max-beta-v0.2.0 https://github.com/RenanEspinar/Alexa-RTSP-Bridge.git
cd Alexa-RTSP-Bridge
cp .env.pro.example .env.pro
python3 -m unittest discover -s tests -v
docker compose --env-file .env.pro -f compose.pro.yml config -q
docker compose --env-file .env.pro -f compose.pro.yml up --build -d
```

The control panel is available **only on localhost** at `http://127.0.0.1:8099`. Use an SSH tunnel to reach it from another PC. Add one test camera, click **Probe**, and request a snapshot. For Alexa, you still need a Smart Home skill, Home Assistant exposure and a private AWS Lambda, as documented in [ALEXA_AWS.md](docs/ALEXA_AWS.md).

**Home Assistant OS / Supervised:** an add-on package is included in [`alexa_bridge/`](alexa_bridge/). It cannot be installed through the public repository URL until this feature branch is merged into `main`. See [PRO_MAX.md](docs/PRO_MAX.md) for the local-add-on beta procedure. Home Assistant Container users should choose Docker Compose.

## What is measured versus what is planned

- **Confirmed:** the original installation's real Fire TV playback video.
- **Passed locally:** HMAC validation, credential-safe settings, codec selection, HLS server protection, idle watchdog behavior, and synthetic FFmpeg H.264/MPEG-TS HLS delivery.
- **Not yet measured:** real camera CPU usage, startup latency, concurrent streams, HA add-on deployment, full Alexa playback with this beta, or reliable Fire TV thumbnails.

This version provides a `snapshot.jpg` API, but **Fire TV controls its own preview tiles**. It is not currently wired into `Alexa.SmartVision.SnapshotProvider`, and I cannot claim thumbnails will populate from it.

## Project files

- **[Pro Beta: full installation, security and acceptance tests](docs/PRO_MAX.md)**
- [AWS Lambda and Alexa Smart Home setup](docs/ALEXA_AWS.md)
- [Original architecture and deployment differences](docs/ARCHITECTURE.md)
- [Previous RC1 README](docs/RC1_README.md)
- [Security notes](docs/SECURITY.md)
- [Measured playlist/segment timings](tools/benchmark_promax.py) · [Automated tests](tests/) and [original Fire TV recording](https://github.com/RenanEspinar/Alexa-RTSP-Bridge/blob/main/Alexa_RTSP_Bridge_FireTV_README_1080p.mp4)

If you test it, please include your camera's video codec/profile, host CPU, first-frame delay, Docker/HA version and sanitized logs. Don't share camera passwords, signed video URLs or security footage in an issue.

Built by [Renan Espinar](https://github.com/RenanEspinar) · MIT licensed · Unaffiliated with Amazon, Cloudflare or Home Assistant.
