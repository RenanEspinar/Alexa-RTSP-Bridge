# Alexa RTSP Bridge Pro — current validation

Build: `0.2.0b1` · status: **experimental** · assessed on local test infrastructure.

| Check | Result | Evidence / limit |
|---|---|---|
| Python code imports and syntax | Pass | `python -m compileall -q alexa_bridge/promax` |
| JavaScript syntax | Pass | `node --check alexa_bridge/promax/static/app.js` |
| Shell entrypoint | Pass | `bash -n alexa_bridge/run.sh` |
| Compose and HA app YAML syntax | Pass | YAML parsed; not a Docker/HA Supervisor acceptance test |
| Signature / expiry / tamper rejection | Pass | Unit tests |
| Invalid RTSP inputs / duplicate endpoint mapping | Pass | Unit tests |
| Private camera settings / credential redaction | Pass | Storage and HTTP tests |
| Unauthorized admin snapshot and media requests | Pass | HTTP tests |
| Automatic copy / transcode decisions | Pass | Unit tests using synthetic codec metadata |
| Watchdog: stop idle; retry after failure | Pass | Unit tests with mocked FFmpeg process |
| Real local FFmpeg H.264 → MPEG-TS HLS | Pass | Synthetic FFmpeg test pattern, verified TS sync byte + ffprobe H.264 |
| Full live RTSP-to-HLS using Docker image | **Pending** | No Docker daemon / live camera was used for beta tests |
| Build of HA add-on on HA OS / Supervised | **Pending** | HA Supervisor unavailable in local validation |
| Lambda RC1 with Pro gateway on actual Alexa / Fire TV | **Pending** | Requires separate AWS skill / device testing |
| CPU, startup time and failure recovery under real camera load | **Pending** | Needs measured hardware baseline |
| Snapshot API actually fills Fire TV dashboard tiles | **Not claimed** | Fire TV manages preview behavior; API not integrated with SnapshotProvider |

The previous Fire TV video is evidence for the **original running installation only**.

A local ZIP/PowerShell publish script is included. No changes have been applied to the user's Ubuntu server. Publishing this beta to a separate branch does not merge it into `main`.
