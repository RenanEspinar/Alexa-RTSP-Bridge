param(
    [string]$PackageRoot = $PSScriptRoot
)
$ErrorActionPreference = 'Stop'
$repo = 'https://github.com/RenanEspinar/Alexa-RTSP-Bridge.git'
$base = 'review/reproducible-rc1-20261118'
$branch = 'feature/pro-max-beta-v0.2.0'
$work = Join-Path $env:TEMP ('alexa_pro_beta_' + [guid]::NewGuid().ToString('N').Substring(0,8))

function RunGit([string[]]$Arguments) {
    & git @Arguments
    if ($LASTEXITCODE -ne 0) { throw ('Error de Git: ' + ($Arguments -join ' ')) }
}

Write-Host "`n== Revisando instalacion de Git ==" -ForegroundColor Cyan
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Git no esta instalado.' }
if (-not (Test-Path (Join-Path $PackageRoot 'alexa_bridge\promax\service.py'))) {
    throw 'No encuentro el paquete Pro Beta. Extrae el ZIP completo primero.'
}

Write-Host "`n== Clonando RC1 en una carpeta NUEVA ==" -ForegroundColor Cyan
RunGit -Arguments @('clone','--single-branch','--branch',$base,$repo,$work)
# No tocamos main ni el servidor Ubuntu.
$already = & git -C $work ls-remote --heads origin "refs/heads/$branch"
if ($LASTEXITCODE -ne 0) { throw 'No se pudo consultar la rama remota.' }
if ($already) { throw "La rama $branch ya existe. Para evitar sobrescribirla se detuvo la publicacion." }
RunGit -Arguments @('-C',$work,'switch','-c',$branch)

# Guardar el README de RC1 antes de sustituirlo en la nueva rama.
New-Item -ItemType Directory -Force -Path (Join-Path $work 'docs') | Out-Null
Copy-Item -LiteralPath (Join-Path $work 'README.md') -Destination (Join-Path $work 'docs\RC1_README.md')

$files = @(
  'README.md', 'repository.yaml', 'compose.pro.yml', '.env.pro.example', 'CHECK_RESULTS_PRO_BETA.md',
  'alexa_bridge\config.yaml', 'alexa_bridge\Dockerfile', 'alexa_bridge\run.sh',
  'alexa_bridge\DOCS.md', 'alexa_bridge\CHANGELOG.md',
  'alexa_bridge\promax\__init__.py','alexa_bridge\promax\security.py',
  'alexa_bridge\promax\store.py','alexa_bridge\promax\media.py',
  'alexa_bridge\promax\service.py',
  'alexa_bridge\promax\static\index.html',
  'alexa_bridge\promax\static\app.css',
  'alexa_bridge\promax\static\app.js',
  'docs\PRO_MAX.md', 'lambda\lambda.py', 'tools\benchmark_promax.py', 'tests\test_promax.py','tests\test_hls_synthetic.py',
  '.github\workflows\pro-max-tests.yml'
)
Write-Host "`n== Copiando archivos de la beta ==" -ForegroundColor Cyan
foreach ($rel in $files) {
    $src = Join-Path $PackageRoot $rel
    $dest = Join-Path $work $rel
    if (-not (Test-Path -LiteralPath $src)) { throw "Falta archivo: $rel" }
    New-Item -ItemType Directory -Force -Path (Split-Path $dest -Parent) | Out-Null
    Copy-Item -LiteralPath $src -Destination $dest -Force
}
# Los settings privados quedan fuera del control de versiones.
Add-Content -LiteralPath (Join-Path $work '.gitignore') -Value "`n# Pro beta private configuration`n.env.pro`nalexa_bridge/data/`ncompose.pro.override.yml`n" -Encoding utf8

Write-Host "`n== Preparando cambios ==" -ForegroundColor Cyan
RunGit -Arguments @('-C',$work,'-c','core.autocrlf=false','add','README.md','docs/RC1_README.md','docs/PRO_MAX.md',
    'repository.yaml','compose.pro.yml','.env.pro.example','CHECK_RESULTS_PRO_BETA.md','alexa_bridge','lambda/lambda.py','tools/benchmark_promax.py','tests/test_promax.py',
    'tests/test_hls_synthetic.py','.github/workflows/pro-max-tests.yml','.gitignore')

# Evita el fallo anterior por espacios al final y finales de linea.
RunGit -Arguments @('-C',$work,'diff','--cached','--check')
$status = & git -C $work diff --cached --name-only
if (-not $status) { throw 'No se encontraron archivos nuevos para publicar.' }

Write-Host "`n== Pruebas Python (si esta instalado) ==" -ForegroundColor Cyan
$python = Get-Command python -ErrorAction SilentlyContinue
if ($python) {
    & python -m unittest discover -s (Join-Path $work 'tests') -v
    if ($LASTEXITCODE -ne 0) { throw 'Las pruebas no pasaron. Nada se ha publicado.' }
} else {
    Write-Host 'Python no esta instalado en Windows: las pruebas deben ejecutarse en CI.' -ForegroundColor Yellow
}

Write-Host "`n== Archivos preparados ==" -ForegroundColor Green
& git -C $work diff --cached --stat
Write-Host "`nSolo se publicara $branch, NO main." -ForegroundColor Yellow
Write-Host 'La beta aun no esta probada con Alexa ni Docker en produccion.' -ForegroundColor Yellow
$confirm = Read-Host 'Escribe SUBIR para publicar la rama nueva'
if ($confirm -ne 'SUBIR') {
    Write-Host "Cancelado. Archivos de trabajo: $work" -ForegroundColor Yellow
    exit 0
}

RunGit -Arguments @('-C',$work,'commit','-m','feat: add Pro beta dashboard, HA addon and on-demand HLS gateway')
RunGit -Arguments @('-C',$work,'push','-u','origin',$branch)
Write-Host "`nPUBLICADO EN GITHUB:" -ForegroundColor Green
Write-Host "https://github.com/RenanEspinar/Alexa-RTSP-Bridge/tree/$branch"
Write-Host "Pull request: https://github.com/RenanEspinar/Alexa-RTSP-Bridge/compare/review/reproducible-rc1-20261118...$branch"
Write-Host "Carpeta de trabajo: $work"
