# Alexa RTSP Bridge Pro — experimental v0.2.0 beta

This version is an **independent implementation** within the Alexa RTSP Bridge project. It is not copied from other projects. The live eight-camera server running the original version has not been altered.

## What has changed

| Feature | Original server | Pro beta |
|---|---|---|
| Interface | Ubuntu scripts | Browser dashboard for cameras and status |
| Video pipeline | H.264 transcode | `auto`, `copy` and `transcode` |
| Demand detection | Playlist requests | Playlist requests, per-camera subprocesses |
| Recovery | Manual controller restart after Docker socket outage | No Docker socket; local FFmpeg watchdog and restart cooldown |
| Thumbnails | No dedicated JPEG API | On-request, cached JPEG snapshots |
| Stream access | HTTPS endpoint | HMAC-SHA256 signed playlist, segment and snapshot paths |
| HA OS integration | No HA add-on | Experimental Home Assistant add-on |
| Ubuntu with HA Container | Running original setup | Separate, isolated Docker deployment |

**Copy-mode note:** remuxing does not change the camera's keyframe interval. If the source uses long GOPs or unusual SPS/PPS formatting, use `transcode` instead of `copy`.

**Unverified:** Fire TV/Alexa end-to-end playback of this new version, HA add-on deployment on HA OS, real H.264 copy compatibility, performance, Apple/Android HLS clients and Fire TV thumbnail consumption. Features are implemented and offline-tested; this is not yet a stable release.

## A. Recommended for your current Ubuntu setup: isolated Docker test

Your existing Home Assistant runs as a Docker container, **not HA OS**. The add-on store is not available in that installation. Use this standalone Pro beta **on a separate test host or VM** first. It uses new container names and different ports so your running `alexa_ondemand` remains untouched.

```bash
# Clone the feature branch after it has been published.
git clone --branch feature/pro-max-beta-v0.2.0 \
  https://github.com/RenanEspinar/Alexa-RTSP-Bridge.git
cd Alexa-RTSP-Bridge

cp .env.pro.example .env.pro
# Select unused ports in .env.pro for the test host.
docker compose --env-file .env.pro -f compose.pro.yml config -q
docker compose --env-file .env.pro -f compose.pro.yml up --build -d
docker compose --env-file .env.pro -f compose.pro.yml ps
```

**Before deploying:** check `ss -ltn` to confirm ports 8090 and 8099 are unused. In your original homeserver, port 8090 is already used by Nginx. **Do not execute this Compose there with defaults.** On the same host, use **different local ports** such as `HLS_PORT=18090`, `UI_PORT=18099`, and be aware that any tests may request camera streams. A separate VM/host is safer.

The UI binds only to `127.0.0.1`. If testing on a separate Ubuntu host, open an SSH tunnel from Windows:

```powershell
ssh -L 18099:127.0.0.1:18099 -L 18090:127.0.0.1:18090 renan@YOUR_TEST_HOST
```

Open `http://127.0.0.1:18099` in your Windows browser. The UI is **not authenticated independently**: its protection depends on binding to loopback + trusted SSH or Home Assistant Ingress. Never publish UI port 8099 or 18099 on the internet.

From the UI, add one test camera, fill the RTSP URL and Alexa endpoint ID, press **Probe**, and request a JPEG using **Snapshot**. Press **Test HLS** to copy a signed playback URL using the HLS port reachable from your browser; paste that URL into VLC to request the live stream. Use only a camera you are authorized to access. Camera credentials and signing key persist in a Docker named volume and are never included in the source repository.

### Test local HLS without Alexa

Copy the generated key from the admin UI only into a trusted local terminal, or read it from the Docker volume locally. The RC1 URL-signing helper is compatible with this version's signature format. Alternatively, use the UI's signed URL endpoint (available only on the admin port):

```bash
# Get the CSRF token from the locally tunneled UI (admin only).
# Then POST to /api/sign/front_door with X-Bridge-CSRF header.
# The result is a path of the form /s/TIMESTAMP/HMAC/front_door/index.m3u8.
```

Combine the path with the local HLS port (e.g. `http://127.0.0.1:18090`) and test using VLC or curl. First playlist requests may take 5–20 seconds depending on camera RTSP startup and `ffprobe`. A signed URL is a **temporary access credential**; do not post it publicly.

### Test HTTPS and Alexa

Only after local HLS is verified, configure a new HTTPS hostname through your tunnel to the HLS port. The admin UI stays private. Configure a **separate test AWS Lambda** using the existing RC1 `lambda/lambda_function.py` and its private environment values. In the dashboard, copy the Alexa endpoint map and the signing key. Do not replace the Lambda currently serving your working cameras until a real Fire TV test succeeds.

## B. Home Assistant OS / Supervised add-on

The repository includes `repository.yaml` and `alexa_bridge/config.yaml`. The Home Assistant add-on store reads the **default GitHub branch**. Until these files are merged into `main`, the one-click repository URL **will not install this beta**. Test it as a *local add-on* first (copy `alexa_bridge/` into `/addons/alexa_rtsp_bridge_pro/` in an HA OS/Supervised test system and refresh the add-on store). After release and merge, the public repository URL can be added in the Home Assistant add-on store.

Open the add-on via **Ingress** (authenticated by Home Assistant). Signed HLS runs on port 8090; route that port over HTTPS for Alexa. Never point external clients at the Ingress admin port.

## Security model and known limits

- Public video paths are HMAC signed with a maximum lifetime of 3600 seconds; a captured valid URL is usable until expiry.
- RTSP URLs stay in private `/data/cameras.json` with mode `0600`. The UI hides credentials after saving, and the signing key is only revealed by an explicit admin action.
- No camera images, token values, RTSP URLs or signed URLs are intentionally written to application logs. FFmpeg stderr is suppressed to avoid credential leaks, but this limits remote error diagnostics.
- The separate UI uses HA Ingress or local SSH tunneling; it has **no independent login page** and must never be publicly exposed.
- Snapshots are on request and cached; Fire TV thumbnails are client-controlled. A snapshot endpoint **does not prove** preview tiles will be populated.
- The new process controller never mounts the Docker socket, unlike RC1. FFmpeg stalls use local process termination and exponential cooldown.
- Always inspect HTTPS ingress/WAF rules: Amazon's camera relay must be able to download playlists **and** segments. Rotate any already exposed tunnel tokens.

## Acceptance criteria

1. Offline Python test suite passes. Validate add-on manifest and Docker Compose syntax.
2. Docker image builds on amd64 and aarch64. Verify `ffprobe` and `ffmpeg` exist inside the container.
3. Add, edit, delete cameras in the UI; credentials do not appear in GET responses or logs.
4. `auto`/`copy` with known H.264 camera and `auto`/`transcode` with H.265 camera (where available).
5. Snapshot JPEG is current, valid, and rejects unsigned access on media port.
6. Signed playlist returns 200 and playable TS segments. Invalid/tampered/expired paths return 403.
7. 30 seconds without playlist requests terminates that camera, independently of other cameras.
8. Kill a running FFmpeg process; verify recovery after cooldown while viewer is requesting playlists.
9. Alexa skill discovery, signed URL playback and PiP on real Fire TV; record timings.
10. One unrelated tester follows the instructions from a clean system.

## Comparison policy

Don't claim this is faster or better than other integrations without measurements. Benchmark H.264 copy CPU, startup latency, concurrent streams, stability and setup time using the same cameras and host. Alexa RTSP Bridge Pro's distinctive implementation is a signed, on-demand HLS gateway with both Docker and Home Assistant add-on packaging.
