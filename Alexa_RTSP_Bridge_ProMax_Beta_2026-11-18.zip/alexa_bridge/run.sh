#!/bin/sh
set -eu
# In Supervisor, /data is persistent and options.json is managed by HA.
# Standalone Docker uses the same directory in its named volume.
mkdir -p "${DATA_DIR:-/data}"
exec python3 -m promax.service
