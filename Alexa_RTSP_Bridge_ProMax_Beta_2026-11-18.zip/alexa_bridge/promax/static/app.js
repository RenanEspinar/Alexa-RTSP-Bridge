'use strict';
let state = {csrf:'',cameras:[],status:{}};
const $ = id => document.getElementById(id);
const toast = message => { $('toast').textContent = message; $('toast').hidden = false; setTimeout(()=>$('toast').hidden=true,4200); };
async function api(path, method='GET', data=null) {
  const opt = {method, headers:{}};
  if (state.csrf) opt.headers['X-Bridge-CSRF'] = state.csrf;
  if (method !== 'GET') { opt.headers['Content-Type']='application/json'; opt.body=JSON.stringify(data||{}); }
  const res = await fetch(path,opt);
  const parsed = await res.json().catch(()=>({error:'Server did not return JSON'}));
  if(!res.ok) throw new Error(parsed.error||'Request failed');
  return parsed;
}
function button(label, fn, extra='') {const b=document.createElement('button');b.className='button '+extra;b.textContent=label;b.onclick=fn;return b;}
async function refresh() {
  try {state = await api('api/state');draw();}catch(e){toast('Could not reach the gateway: '+e.message);}
}
function draw() {
  $('count').textContent=state.cameras.length;
  $('online').textContent=Object.values(state.status).filter(s=>s.running).length;
  $('uptime').textContent=Math.floor(state.uptime_seconds/60)+' min';
  const root=$('cameras');root.replaceChildren();
  if(!state.cameras.length){const p=document.createElement('p');p.textContent='No cameras configured yet. Add your first RTSP camera.';root.append(p);return;}
  state.cameras.forEach(cam=>{
    const st=state.status[cam.slug]||{};
    const card=document.createElement('article');card.className='camera';
    const thumb=document.createElement('div');thumb.className='thumb';
    const placeholder=document.createElement('span');placeholder.textContent='◉ Camera snapshot';thumb.append(placeholder);
    const body=document.createElement('div');body.className='camera-body';
    const title=document.createElement('div');title.className='cam-title';
    const name=document.createElement('b');name.textContent=cam.name;
    const badge=document.createElement('span');badge.className='badge'+(st.running?' online':'');badge.textContent=st.running?'● STREAMING':'○ IDLE';title.append(name,badge);
    const meta=document.createElement('p');meta.className='meta';meta.textContent=cam.slug+' · '+cam.mode.toUpperCase()+(st.mode?' → '+st.mode:'')+' · '+(st.starts||0)+' starts';
    const actions=document.createElement('div');actions.className='actions';
    actions.append(
      button('Snapshot',async()=>{try{
        const r=await fetch('api/snapshot/'+cam.slug,{headers:{'X-Bridge-CSRF':state.csrf}});
        if(!r.ok)throw new Error('Snapshot unavailable');
        const url=URL.createObjectURL(await r.blob());const img=document.createElement('img');
        img.src=url;img.onload=()=>{thumb.replaceChildren(img);setTimeout(()=>URL.revokeObjectURL(url),30000);};
      }catch(e){toast(e.message);}}),
      button('Probe',async()=>{try{const p=await api('api/probe/'+cam.slug,'POST');toast(`${cam.name}: ${p.codec} / ${p.profile} — ${p.recommended_mode}`);}catch(e){toast(e.message);}}),
      button('Test HLS',async()=>{
        try{
          const result=await api('api/sign/'+cam.slug,'POST');
          const base=prompt('Local HLS base (e.g. http://127.0.0.1:8090). This generates a PRIVATE link:', 'http://127.0.0.1:8090');
          if(!base)return;
          if(!/^https?:\/\/[^\s]+$/.test(base)) throw new Error('Enter a valid local HLS base URL');
          await navigator.clipboard.writeText(base.replace(/\/$/,'')+result.path);
          toast('Signed playback URL copied (10-minute expiry). Keep it private.');
        }catch(e){toast(e.message);}
      }),
      button('Edit',()=>edit(cam)),
      button('⋯',async()=>{if(confirm('Delete '+cam.name+'?')){try{await api('api/cameras/'+cam.slug,'DELETE');refresh();}catch(e){toast(e.message);}}})
    );
    body.append(title,meta,actions);card.append(thumb,body);root.append(card);
  });
}
function edit(cam=null){const form=$('camera-form');form.reset();$('form-error').textContent='';
  if(cam){for(const k of ['slug','name','alexa_endpoint_id','mode','fps','width','height','bitrate_kbps']) form.elements[k].value=cam[k];form.elements.slug.readOnly=true;}
  else form.elements.slug.readOnly=false;
  $('editor').showModal();
}
$('new').onclick=()=>edit();$('close').onclick=()=>$('editor').close();$('cancel').onclick=()=>$('editor').close();
$('camera-form').onsubmit=async event=>{event.preventDefault();const f=event.target;const obj={};
  for(const k of ['slug','name','alexa_endpoint_id','mode','rtsp_url']) obj[k]=f.elements[k].value;
  for(const k of ['fps','width','height','bitrate_kbps']) obj[k]=Number(f.elements[k].value);
  try{await api('api/cameras','POST',obj);$('editor').close();toast('Camera saved');refresh();}
  catch(e){$('form-error').textContent=e.message;}
};
$('map').onclick=async()=>{try{const map=await api('api/endpoint-map');await navigator.clipboard.writeText(JSON.stringify(map));toast('Endpoint map copied. Paste it into CAMERA_ENDPOINT_MAP_JSON.');}catch(e){toast(e.message);}};
$('key').onclick=async()=>{if(!confirm('The signing key grants temporary access to your streams. Only copy it into your private Lambda configuration. Continue?'))return;
  try{const val=await api('api/secret','POST',{confirm:'I_UNDERSTAND'});await navigator.clipboard.writeText(val.key);toast('Private signing key copied. Do not share this clipboard content.');}catch(e){toast(e.message);}};
refresh();setInterval(refresh,10000);
