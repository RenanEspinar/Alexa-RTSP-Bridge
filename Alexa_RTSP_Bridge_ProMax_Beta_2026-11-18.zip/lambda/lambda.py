"""Compatibility entrypoint for older AWS Lambda handler configurations.

Use lambda_function.lambda_handler in new deployments. Keeping this alias avoids
running the older proxy, which logged full Alexa directives and access tokens.
"""
from lambda_function import lambda_handler

__all__ = ['lambda_handler']
