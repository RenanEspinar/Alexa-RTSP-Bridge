# Protocolo de evaluación reproducible — Alexa RTSP Bridge Pro Max

**Versión:** 0.1 | **Fecha:** 2026-11-19 | **Ámbito:** ensayo local, un servidor Ubuntu.

## Objetivo y alcance

Estimar, para N=1,4,8 canales solicitados simultáneamente, el retardo hasta el primer segmento MPEG-TS, continuidad de acceso HLS, CPU/RAM de la aplicación durante 60 segundos de carga sostenida y retorno a reposo. Las métricas se toman desde el propio servidor Ubuntu mediante HTTP local, no desde Alexa. No se estudia eficacia de alarmas, seguridad física o disponibilidad del sistema de videovigilancia.

## Variables

- **N**: cantidad de canales que solicitan una playlist HLS simultáneamente, sin unidad.
- **t_playlist (s)**: tiempo monótono desde el inicio de la etapa hasta la primera respuesta de playlist que comienza por `#EXTM3U`.
- **t_TS (s)**: tiempo monótono hasta recibir un segmento de transporte con longitud múltiplo de 188 bytes y bytes de sincronización válidos en los primeros paquetes. No equivale a decodificación de video, primer fotograma ni latencia glass-to-glass.
- **U_CPU (%)**: porcentaje de CPU reportado por `docker stats` sobre el contenedor Pro Max. 100 % ≈ un núcleo lógico utilizado. Se registran promedio simple de muestras y máximo de muestras de la ventana sostenida.
- **M_RAM (MiB)**: memoria reportada por `docker stats`; se registra máximo *observado* de la ventana sostenida.
- **S_i (segmentos)**: número de nombres de segmentos TS distintos obtenidos y verificados por el cliente i; indica continuidad de entrega observada, no frames por segundo.
- **E_i**: recuento de errores HTTP y de validación por canal.
- **Idle**: estado `running=false` para cada canal después de un margen de 46 s tras detener las solicitudes. No verifica apagado eléctrico del grabador.

## Procedimiento

1. Confirmar que el sistema original de Alexa sigue operativo y que todas las cámaras Pro Max están en `IDLE`.
2. Mantener la misma resolución objetivo, FPS, bitrate, modo y versiones en todas las repeticiones. Anotar los parámetros en el cuaderno de ensayo (sin credenciales).
3. Ejecutar el script con `--concurrency all --duration 60`. El cliente solicita las playlists en paralelo, espera hasta 45 s el primer TS y mantiene el tráfico durante 60 s. Descarga como máximo un nuevo segmento por ciclo.
4. Muestrear CPU y RAM del contenedor con `docker stats --no-stream`. El muestreo es periódico; no captura necesariamente picos instantáneos.
5. Dejar 46 s para el apagado por inactividad; el script registra si todos los procesos se detuvieron. El ensayo termina antes si la CPU Docker supera 330 % durante tres muestras o si el host queda con menos de 750 MiB disponibles.
6. Repetir 3 veces en distintos momentos o alternar orden de las etapas para estudiar calentamiento, caché y variabilidad. Cada ejecución genera carpeta independiente en `~/alexa-promax-resultados/`.
7. Revisar `summary.csv`, `cameras_*.csv`, `samples_*.csv`, `metadata.json`; anonimizar salidas, comprobar consistencia y subirlas al repositorio junto con versión de commit de código.

## Limitaciones y confusores

- Los ocho canales provienen del mismo dispositivo grabador. El ensayo no prueba interoperabilidad entre fabricantes ni cámaras físicas independientes.
- Solicitar `.ts` periódicamente no simula el comportamiento exacto de Alexa/ACRS ni de un reproductor continuo con almacenamiento en buffer.
- El flujo cliente-servidor es local (`127.0.0.1`), por lo que excluye latencia Cloudflare, AWS y acceso externo.
- La configuración `auto` puede resolver a `transcode`; una comparación con `copy` solo es válida si ambos flujos son decodificables y usan la misma cámara/condiciones.
- Las muestras `docker stats` incorporan el proceso Python y FFmpeg de Pro Max, no necesariamente todo el consumo del grabador ni del host.
- El primer segmento disponible no garantiza reproducción visible ni calidad.
- En un solo host no hay muestra poblacional de instalaciones. Evitar inferencia estadística generalizante.

## Buenas prácticas de publicación

No versionar `configuration.yaml`, URLs `rtsp://`, IPs privadas, contraseñas, claves HMAC, enlaces HLS firmados, snapshots o imágenes de la vivienda. Los CSV del script usan etiquetas `camera_01` ... `camera_08`.

## Criterios para una comparación con otro software

Usar las mismas fuentes RTSP, equipo, red, perfiles de codificación y número de sesiones. Alternar el orden A/B para reducir sesgos térmicos o de carga, repetir al menos 3 ensayos y reportar medias, dispersión, fallos y diferencias de comportamiento. Atribuir software y licencias originales. No afirmar 'mejor' sin evaluar funcionalidades y rendimiento bajo condiciones equivalentes.
