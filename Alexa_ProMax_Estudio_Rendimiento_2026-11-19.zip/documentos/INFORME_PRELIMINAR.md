# Alexa RTSP Bridge Pro Max — informe de rendimiento preliminar

**Fecha:** 19 de noviembre de 2026  
**Versión evaluada:** `v0.2.0b1`  
**Tipo de evidencia:** medición local reportada por el operador de la instalación; una ejecución por condición.  
**Condición:** 1, 4 u 8 canales RTSP de un mismo grabador, servidos mediante FFmpeg/HLS en Docker.

## Resumen ejecutivo

En la instalación doméstica evaluada, Pro Max produjo el primer segmento MPEG-TS de todos los canales solicitados en los ensayos con 1, 4 y 8 cámaras. En la etapa de ocho canales, el promedio de CPU observado fue **154,1 % Docker** (equivale aproximadamente a 1,54 núcleos), con pico de **211,44 %** y **628,5 MiB de RAM en la última muestra**. El tiempo medio hasta el primer segmento de los ocho canales fue **10.33 s**. Después del período de inactividad, no quedaron cámaras activas y el contenedor volvió a **0,03 % de CPU y 17,28 MiB de RAM**.

Estos datos respaldan **factibilidad preliminar**, no estabilidad a largo plazo, calidad visual, latencia perceptual ni ventajas frente a otro producto.

## Recursos del sistema

- CPU lógica disponible: **4 núcleos**.
- Memoria RAM total observada: **7,1 GiB**.
- Memoria disponible antes del ensayo: **5,3 GiB**.
- Swap prácticamente sin uso.
- Contenedores coexistentes: Home Assistant, Cloudflare Tunnel y otros servicios domésticos. No se aisló el host para el ensayo.
- Origen RTSP: distintos canales configurados en un mismo grabador. No se verificaron cámaras físicas independientes ni diversidad de fabricantes.

## Datos agregados

| Canales concurrentes | CPU media Docker | CPU pico Docker | RAM última muestra | Primer TS válido | Inactivos al final |
|---|---:|---:|---:|---:|---:|
| 1 | 35,7 % | 76,69 % | 107,3 MiB | 1/1 | Sí |
| 4 | 107,3 % | 150,21 % | 319,4 MiB | 4/4 | Sí |
| 8 | 154,1 % | 211,44 % | 628,5 MiB | 8/8 | Sí |

![CPU según concurrencia](../figuras/cpu_por_concurrencia.png)

**Interpretación:** 100 % en Docker equivale aproximadamente a un núcleo lógico. Por tanto, el pico del ensayo de ocho canales equivalió a 2,11 de los cuatro núcleos. Esta relación no mide la capacidad disponible de todo el host con precisión perfecta; son muestras de un contenedor, no perfiles por hilo.

## Tiempo hasta el primer segmento — etapa de ocho canales

| Canal anonimizado | Segundos |
|---|---:|
| camera_01 | 4,385 |
| camera_02 | 4,371 |
| camera_03 | 7,329 |
| camera_04 | 9,337 |
| camera_05 | 11,317 |
| camera_06 | 15,289 |
| camera_07 | 17,336 |
| camera_08 | 13,281 |

**Media:** 10.331 s. **Máximo observado:** 17,336 s. La medición termina al recibir el primer segmento; no mide el instante en que Alexa empieza a mostrar imagen.

![Primer segmento por canal](../figuras/primer_segmento_8_canales.png)

## Qué se verificó y qué no

**Verificado:** creación de playlist HLS, recepción de al menos un segmento TS por cámara, inicio del proceso FFmpeg bajo demanda y cese posterior por inactividad. La aplicación señaló modo `transcode` para los ocho canales.

**No verificado con este conjunto:** integridad y tasa de entrega durante sesiones continuas, decodificación sostenida en Alexa, variación entre distintas jornadas, compatibilidad multigrabador, eficiencia energética del host, latencia extremo a extremo o comparación controlada con Hu1kSmash.

**Limitación adicional:** la RAM de la prueba anterior se anotó en la **última muestra**, por lo que no puede denominarse valor máximo. Los promedios de CPU proceden de muestreo periódico sin registro bruto conservado para esa ejecución. No se dispone de intervalos de confianza.

## Próximo experimento

Ejecutar `scripts/benchmark_sostenido.py` con una ventana de 60 s tras la preparación de las cámaras. Guardar `samples_*.csv`, `cameras_*.csv`, `summary.csv` y `metadata.json`; repetir **tres veces** por condición, manteniendo idéntica configuración y sin cambios voluntarios de carga. Incluir una muestra de reposo entre pruebas. Publicar solamente resultados anonimizados.

## Referencias técnicas

1. Pantos, R. y May, W. (2017). *HTTP Live Streaming*. RFC 8216. https://www.rfc-editor.org/rfc/rfc8216
2. Amazon Developer. *Alexa.CameraStreamController Interface*. https://developer.amazon.com/docs/alexaplus/device-apis/alexa-camerastreamcontroller
3. Docker Inc. *docker container stats*. https://docs.docker.com/reference/cli/docker/container/stats/

**Procedencia:** mediciones terminales suministradas por el operador durante el ensayo del 19-11-2026. Los CSV incluidos transcriben exactamente esas cifras; no son resultados nuevos ni inventados.
