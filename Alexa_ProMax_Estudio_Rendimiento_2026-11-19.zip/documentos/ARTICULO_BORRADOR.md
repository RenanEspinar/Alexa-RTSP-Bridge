# Manuscrito preliminar — NO LISTO PARA ENVÍO A REVISTA

**Título propuesto:** Evaluación experimental de una pasarela RTSP–HLS bajo demanda para visualización de cámaras IP mediante dispositivos compatibles con Alexa.

**Título en inglés:** Experimental Performance Evaluation of an On-Demand RTSP-to-HLS Gateway for Alexa-Compatible Camera Viewing.

**Autor:** por confirmar afiliación, contribuciones y coautores.  
**Estado:** borrador a partir de una instalación, sin repeticiones independientes ni validación de reproducción Alexa para esta beta.

## Resumen (borrador)

Se evaluó preliminarmente una pasarela RTSP–HLS bajo demanda implementada con Python, FFmpeg y Docker en un servidor Ubuntu de cuatro núcleos lógicos y 7,1 GiB de RAM. El sistema convierte bajo solicitud canales RTSP en segmentos HLS MPEG-TS y finaliza los procesos inactivos. Se realizaron pruebas iniciales con 1, 4 y 8 canales concurrentes procedentes de un mismo grabador. Los ocho canales proporcionaron un primer segmento válido, con tiempo medio de **10.33 s**; el consumo medio de CPU del contenedor fue de **154,1 %** de un núcleo y el máximo observado fue **211,44 %**. La memoria en la última muestra fue de **628,5 MiB** y el sistema regresó a 0,03 % de CPU tras el apagado. Estos resultados sugieren factibilidad técnica de hasta ocho flujos en la instalación evaluada. No permiten concluir estabilidad sostenida, reducción de consumo respecto de alternativas ni compatibilidad de extremo a extremo con dispositivos Alexa para la nueva versión. Se propone un protocolo experimental de 60 s con repetición de ensayos y captura de errores y recursos.

**Palabras clave:** RTSP; HTTP Live Streaming; FFmpeg; Docker; videovigilancia IP; transcodificación bajo demanda; medición de rendimiento.

## 1. Introducción

La integración de cámaras IP con dispositivos de visualización doméstica combina protocolos de adquisición como RTSP y mecanismos de distribución adaptados a clientes remotos. La API `Alexa.CameraStreamController` contempla flujos HLS y RTSP, sujetos a requisitos de endpoint y compatibilidad. RFC 8216 describe la estructura de playlists y segmentos HLS. El trabajo estudia una implementación particular de pasarela bajo demanda, sin pretensión de originalidad del protocolo ni de exclusividad sobre la solución.

**Pregunta de investigación:** ¿cómo evolucionan el retardo de disponibilidad del primer segmento HLS, el consumo CPU/RAM y la continuidad de suministro al aumentar de 1 a 8 canales RTSP concurrentes en un servidor doméstico de cuatro núcleos?

## 2. Materiales y métodos

**Plataforma.** Ubuntu con Docker; 4 núcleos lógicos; 7,1 GiB de RAM. Otras aplicaciones continuaron activas durante el ensayo. Versión de la pasarela `v0.2.0b1`. Las fuentes provienen de distintos canales RTSP de un mismo grabador de red. No publicar credenciales ni identificadores de red internos.

**Intervención.** Para cada N ∈ {1,4,8}, la pasarela recibió N solicitudes simultáneas de playlist HLS. El modo observado fue `transcode`. Se midieron los tiempos locales hasta el primer segmento `.ts` y muestras de consumo del contenedor mediante Docker. El controlador cesa los procesos después de un período de inactividad. La documentación del protocolo se acompaña en `PROTOCOLO.md`.

**Análisis.** Las mediciones existentes constituyen una única corrida por condición. No se calculan intervalos de confianza ni contrastes de significación. En los ensayos futuros se reportarán media, desviación estándar y rango, separando inicio (warm-up) de régimen sostenido (60 s).

## 3. Resultados preliminares

| Canales | CPU promedio Docker | CPU máximo | RAM última muestra | Éxitos primer segmento |
|---:|---:|---:|---:|---:|
| 1 | 35,7 % | 76,69 % | 107,3 MiB | 1/1 |
| 4 | 107,3 % | 150,21 % | 319,4 MiB | 4/4 |
| 8 | 154,1 % | 211,44 % | 628,5 MiB | 8/8 |

El promedio de disponibilidad del primer segmento en N=8 fue **10.331 s**, con valor máximo de **17,336 s**. El contenedor volvió a **0,03 % CPU** y **17,28 MiB** después del apagado. Las cifras de RAM no corresponden necesariamente al máximo, dado que la prueba preliminar retuvo una sola muestra final.

## 4. Discusión y limitaciones

El funcionamiento en demanda reduce la permanencia de FFmpeg cuando no existe una solicitud, pero la prueba no demuestra un ahorro energético cuantificado. Los tiempos de primer segmento crecen de forma irregular por canal, lo que puede deberse a diferencias de codificación de la fuente, recuperación de tramas clave, programación de CPU y condiciones de red interna; no se han aislado causalmente esos factores. Al provenir todos los canales del mismo grabador, el alcance externo es limitado. El comportamiento del cliente Alexa de la versión Pro Max no se probó de extremo a extremo y debe ser objeto de una fase específica.

La investigación solo podrá comparar este desarrollo con otro producto (p. ej., Alexa Cameras HLS de Hu1kSmash) después de fijar un protocolo común y repetir ambos sobre el mismo equipo.

## 5. Trabajo pendiente para envío

- Pruebas sostenidas de 60 s y al menos tres repeticiones independientes por condición.
- Perfil instrumental de cada origen (codec, perfil, resolución real, bitrate, GOP) y de la plataforma (modelo CPU, versiones de Docker/FFmpeg).
- Ensayo controlado con `copy` y `transcode`, incluyendo verificación de decodificabilidad.
- Validación de Alexa/Fire TV con medición de primera imagen real y tasa de fallos.
- Réplica en otro servidor o con otro grabador para validar transferibilidad.
- Comparación A/B con proyecto alternativo bajo idéntica configuración.
- Revisión bibliográfica formal, figuras definitivas, declaración de conflictos y permisos sobre datos de videovigilancia.

## Referencias base (verificación bibliográfica antes de envío)

1. Pantos, R., & May, W. (2017). *HTTP Live Streaming*. RFC 8216. https://www.rfc-editor.org/rfc/rfc8216
2. Amazon Developer. *Alexa.CameraStreamController Interface*. https://developer.amazon.com/docs/alexaplus/device-apis/alexa-camerastreamcontroller
3. Docker Inc. *docker container stats*. https://docs.docker.com/reference/cli/docker/container/stats/
4. Proyecto de comparación: T. Hirt, *Alexa Cameras (HLS)*, https://github.com/Hu1kSmash/ha-alexa-cameras (software de terceros, no evaluado en este ensayo).
