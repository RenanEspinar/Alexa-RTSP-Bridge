"""Smoke test artificial de la API: NO sustituye a la prueba RTSP real."""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import benchmark_sostenido as bench

PACKET = bytes([0x47]) + bytes(187)


class Handler(BaseHTTPRequestHandler):
    count = 0
    def log_message(self, *args):
        pass
    def do_GET(self):
        if self.path == '/api/state':
            data = {'version': '0.2.0b1', 'csrf': 'DUMMY',
                    'cameras': [{'slug': 'solario'}],
                    'status': {'solario': {'running': False, 'mode': 'transcode'}}}
            self.reply(json.dumps(data).encode(), 'application/json')
        elif self.path.endswith('index.m3u8'):
            type(self).count += 1
            self.reply(f'#EXTM3U\n#EXTINF:1.0,\nsegment_{self.count:010}.ts\n'.encode(),
                       'application/vnd.apple.mpegurl')
        elif self.path.endswith('.ts'):
            self.reply(PACKET*5, 'video/mp2t')
        else:
            self.send_error(404)
    def do_POST(self):
        if self.path == '/api/sign/solario':
            n = int(self.headers.get('Content-Length', '0'))
            self.rfile.read(n)
            self.reply(b'{"path":"/s/123/sign/solario/index.m3u8"}', 'application/json')
        else:
            self.send_error(404)
    def reply(self, data, mime):
        self.send_response(200)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)


class HttpSimulatedTest(unittest.TestCase):
    def test_one_stream(self):
        server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        url = f'http://127.0.0.1:{server.server_port}'
        args = SimpleNamespace(admin=url, hls=url, container='fake',
                               duration=1, startup_timeout=3, cooldown=1,
                               poll=0.25, max_cpu=330, min_host_mem=750)
        try:
            state = bench.get_json(url+'/api/state')
            with tempfile.TemporaryDirectory() as folder:
                with patch.object(bench, 'docker_sample', return_value=(12.0, 20.0)), \
                     patch.object(bench, 'wait_idle', return_value=(True, [])):
                    summary = bench.run_stage(1, ['solario'], state, args, Path(folder))
                self.assertEqual(summary['streams_ready'], 1)
                self.assertGreaterEqual(summary['total_unique_segments'], 2)
                self.assertTrue((Path(folder)/'cameras_01.csv').exists())
        finally:
            server.shutdown()
            server.server_close()


if __name__ == '__main__':
    unittest.main()
