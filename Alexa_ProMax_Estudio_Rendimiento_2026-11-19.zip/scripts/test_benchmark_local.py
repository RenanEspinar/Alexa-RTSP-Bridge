import unittest
from benchmark_sostenido import parse_memory,check_ts

class HelpersTest(unittest.TestCase):
    def test_memory(self):
        self.assertEqual(parse_memory('628.5MiB / 7.141GiB'), 628.5)
        self.assertEqual(parse_memory('1GiB / 2GiB'), 1024.0)
    def test_ts(self):
        check_ts(bytes([0x47])+bytes(187) + bytes([0x47])+bytes(187) + bytes([0x47])+bytes(187))
        with self.assertRaises(ValueError):
            check_ts(b'no es transport stream')
        with self.assertRaises(ValueError):
            check_ts(bytes(188*3))

if __name__ == '__main__':
    unittest.main()
