# Paquete de evaluación de rendimiento — Alexa RTSP Bridge Pro Max

**Fecha:** 2026-11-19. **Contenido:** benchmark de 60 s, resultados preliminares de 1/4/8 cámaras, gráficos, protocolo experimental y manuscrito inicial.

## Ejecución en Ubuntu (vía SSH)

```bash
python3 scripts/benchmark_sostenido.py --concurrency all --duration 60
```

El script usa exclusivamente la API local de Pro Max en `127.0.0.1:18099` y HLS en `127.0.0.1:18090`; no necesita capturar contraseñas RTSP ni publicar el panel. Comprueba que las cámaras estén en reposo antes del ensayo. El test no modifica Docker Compose, AWS, Home Assistant ni sus archivos.

Los resultados se guardan en una carpeta privada independiente por ejecución bajo `~/alexa-promax-resultados/`. Después de auditar la salida se pueden subir los archivos `summary.csv`, `cameras_*.csv`, `samples_*.csv` y `metadata.json`.

**Guardarraíles:** interrupción si CPU > 330 % en tres muestras consecutivas o memoria disponible en el host < 750 MiB. El apagado de FFmpeg sigue siendo responsabilidad del watchdog del sistema. El script comprueba el retorno a reposo.

**Repetibilidad:** realizar al menos 3 ejecuciones con igual configuración y conservar datos brutos, versiones, CPU y contexto de carga. El análisis de una sola corrida no demuestra superioridad ni permite intervalos de confianza.

## Documentos

- [Resultados preliminares](documentos/INFORME_PRELIMINAR.md)
- [Protocolo experimental](documentos/PROTOCOLO.md)
- [Borrador de artículo](documentos/ARTICULO_BORRADOR.md)
- [Datos agregados de etapas](datos/resultados_preliminares_etapas.csv)
- [Datos preliminares por cámara](datos/resultados_preliminares_camaras.csv)
- [Script reproducible](scripts/benchmark_sostenido.py)

## Privacidad

No incluir en GitHub URLs RTSP, tokens HLS, hostnames privados, IP de cámaras, contraseñas, capturas del interior de la vivienda ni archivos de configuración. Los resultados publicados deben usar IDs genéricos.

## Alcance de validación del paquete

El código del benchmark fue verificado sintácticamente y con pruebas de utilidad local. No se ejecutó contra el servidor privado desde este entorno. Los resultados preliminares fueron transcritos del log aportado por el operador, no se realizaron nuevas mediciones.
