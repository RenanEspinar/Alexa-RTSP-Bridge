# Publicar el código fuente y los manuales en main. No sube datos privados.
$ErrorActionPreference = 'Stop'
$src = $PSScriptRoot
$repo = 'https://github.com/RenanEspinar/Alexa-RTSP-Bridge.git'
$tmp = Join-Path ([IO.Path]::GetTempPath()) ('alexa-publicacion-' + [guid]::NewGuid().ToString('N'))
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Falta Git for Windows.' }
New-Item -ItemType Directory -Path $tmp -Force | Out-Null
& git clone --branch main --depth 1 $repo $tmp
if ($LASTEXITCODE -ne 0) { throw 'No se pudo clonar main.' }
$dirs = @('alexa_bridge','custom_components','docs','aws','scripts','tests','tools','benchmarks','.github')
$files = @('README.md','LICENSE','compose.pro.yml','repository.yaml','hacs.json','.env.pro.example','.gitignore','RELEASE_MANIFEST.json')
foreach ($d in $dirs) {
  $from = Join-Path $src $d
  if (-not (Test-Path $from)) { throw "Falta la carpeta $d en el paquete" }
  $to = Join-Path $tmp $d
  New-Item -ItemType Directory -Force -Path $to | Out-Null
  Copy-Item -Path (Join-Path $from '*') -Destination $to -Recurse -Force
}
foreach ($f in $files) {
  $from = Join-Path $src $f
  if (-not (Test-Path $from)) { throw "Falta el archivo $f en el paquete" }
  Copy-Item -LiteralPath $from -Destination (Join-Path $tmp $f) -Force
}
Push-Location $tmp
try {
  # Añadimos solo rutas conocidas, sin carpetas de credenciales ni resultados de servidor.
  & git add README.md LICENSE compose.pro.yml repository.yaml hacs.json .env.pro.example .gitignore RELEASE_MANIFEST.json alexa_bridge custom_components docs aws scripts tests tools benchmarks .github
  if ($LASTEXITCODE -ne 0) { throw 'Error en git add' }
  & git diff --cached --check
  if ($LASTEXITCODE -ne 0) { throw 'Hay errores de espacios o formato en el diff' }
  Write-Host "`n=== RESUMEN DE CAMBIOS ==="
  & git diff --cached --stat
  Write-Host "`n=== ARCHIVOS CAMBIADOS ==="
  & git diff --cached --name-only
  $change = & git diff --cached --name-only
  if (-not $change) { Write-Host 'No hay cambios para subir.'; exit 0 }
  $answer = Read-Host 'Escribe SUBIR para confirmar commit y push a main'
  if ($answer -cne 'SUBIR') { Write-Host 'Cancelado'; exit 0 }
  & git commit -m 'feat: Pro v0.3 wizard, Marketplace adapter and measured docs'
  if ($LASTEXITCODE -ne 0) { throw 'No se pudo hacer commit. Revisa git user.name y user.email' }
  & git push origin main
  if ($LASTEXITCODE -ne 0) { throw 'No se pudo subir. Revisa autenticación o cambios remotos' }
  Write-Host "PUBLICADO: https://github.com/RenanEspinar/Alexa-RTSP-Bridge"
} finally { Pop-Location }
