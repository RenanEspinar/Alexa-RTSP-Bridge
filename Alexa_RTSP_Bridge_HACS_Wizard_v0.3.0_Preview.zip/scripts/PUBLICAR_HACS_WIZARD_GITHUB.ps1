# Publishes the HACS adapter and preview to a NEW feature branch only.
$ErrorActionPreference = 'Stop'
$source = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$repoUrl = 'https://github.com/RenanEspinar/Alexa-RTSP-Bridge.git'
$branch = 'feature/hacs-wizard-preview-v0.3.0'
$work = Join-Path ([System.IO.Path]::GetTempPath()) ('alexa-hacs-' + [guid]::NewGuid().ToString('N'))

function ExecGit([string[]]$arguments) {
    & git @arguments
    if ($LASTEXITCODE -ne 0) { throw ('git failed: ' + ($arguments -join ' ')) }
}

Write-Host '=== CHECKING TOOLS ==='
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Git for Windows is required' }
New-Item -ItemType Directory -Path $work -Force | Out-Null
Write-Host '=== CLONING MAIN ==='
ExecGit -arguments @('clone', '--branch', 'main', '--depth', '1', $repoUrl, $work)
Push-Location $work
try {
    ExecGit -arguments @('switch', '-c', $branch)
    foreach ($relative in @(
        'custom_components', 'alexa_bridge', 'hacs.json',
        'compose.wizard-preview.yml', 'repository.yaml',
        'docs/INSTALL_GUIDED.md',
        'scripts/start_wizard_preview.sh', 'scripts/stop_wizard_preview.sh',
        '.github/workflows/wizard-preview.yml',
        'tests/test_hacs_package.py', 'tests/test_promax.py', 'tests/test_hls_synthetic.py'
    )) {
        $src = Join-Path $source $relative
        $dest = Join-Path $work $relative
        if (Test-Path $src -PathType Container) {
            New-Item -ItemType Directory -Path $dest -Force | Out-Null
            Copy-Item -Path (Join-Path $src '*') -Destination $dest -Recurse -Force
        } elseif (Test-Path $src -PathType Leaf) {
            $parent = Split-Path -Parent $dest
            New-Item -ItemType Directory -Path $parent -Force | Out-Null
            Copy-Item -LiteralPath $src -Destination $dest -Force
        } else { throw "Missing package file: $relative" }
    }
    $readme = Join-Path $work 'README.md'
    $marker = '## Guided setup / HACS adapter preview'
    if (-not ((Get-Content $readme -Raw).Contains($marker))) {
        Add-Content -Path $readme -Value "`n$marker`n`nThis preview adds a browser setup wizard and a Home Assistant custom integration; HACS does not install the Docker gateway. See [guided setup](docs/INSTALL_GUIDED.md).`n"
    }
    ExecGit -arguments @('add', 'README.md', 'custom_components', 'alexa_bridge', 'hacs.json',
        'compose.wizard-preview.yml', 'repository.yaml', 'docs/INSTALL_GUIDED.md',
        'scripts/start_wizard_preview.sh', 'scripts/stop_wizard_preview.sh',
        '.github/workflows/wizard-preview.yml', 'tests/test_hacs_package.py',
        'tests/test_promax.py', 'tests/test_hls_synthetic.py')
    & git diff --cached --stat
    if ($LASTEXITCODE -ne 0) { throw 'Unable to show staged changes' }
    $confirm = Read-Host 'Type SUBIR to publish ONLY the feature branch (main stays untouched)'
    if ($confirm -cne 'SUBIR') { Write-Host 'Cancelled; nothing pushed'; exit }
    ExecGit -arguments @('commit', '-m', 'feat: add HACS integration and setup wizard preview')
    ExecGit -arguments @('push', '-u', 'origin', $branch)
    Write-Host "Published feature branch: https://github.com/RenanEspinar/Alexa-RTSP-Bridge/tree/$branch"
} finally { Pop-Location }
