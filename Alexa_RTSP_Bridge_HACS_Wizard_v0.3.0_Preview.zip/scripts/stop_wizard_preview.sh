#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
# No --volumes: the preview's camera configuration is preserved.
docker compose -f compose.wizard-preview.yml down
