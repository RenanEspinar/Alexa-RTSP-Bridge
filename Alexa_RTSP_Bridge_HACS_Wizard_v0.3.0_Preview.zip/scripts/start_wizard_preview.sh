#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "${1:-}" != "--run" ]]; then
  echo 'This is a side-by-side preview. It does not replace the running beta.'
  echo 'Ports: localhost:18199 (admin), localhost:18190 (signed HLS).'
  echo 'To start it intentionally: bash scripts/start_wizard_preview.sh --run'
  exit 0
fi
if ! command -v docker >/dev/null; then
  echo 'Docker is required; stopping without changes.' >&2
  exit 1
fi
if docker ps -a --format '{{.Names}}' | grep -Fxq alexa_rtsp_bridge_wizard_preview; then
  echo 'Preview already exists; not modifying it.' >&2
  exit 1
fi
python3 - <<'PY'
import socket
for port in (18199,18190):
    with socket.socket() as s:
        try:
            s.bind(('127.0.0.1',port))
        except OSError:
            raise SystemExit(f'Port {port} is already occupied; no changes made.')
PY
docker compose -f compose.wizard-preview.yml config -q
docker compose -f compose.wizard-preview.yml up --build -d
printf '
Open http://127.0.0.1:18199 on the Docker host or through a protected SSH tunnel.
'
printf 'For remote access, configure Cloudflare Access before publishing a hostname.
'
