# Checklist antes de anunciar integración HACS pública

- [x] `custom_components/alexa_rtsp_bridge` con manifest, config flow y sensores
- [x] Wizard en el dashboard (cuatro pasos)
- [x] Docker preview separado del servidor existente
- [x] Pruebas locales Python y validación sintáctica JavaScript/Bash
- [ ] Prueba manual de HACS 2.x instalando desde la rama principal o release
- [ ] Prueba manual de Home Assistant Container real, incluida la topología Docker
- [ ] Validación de actualización con copia de seguridad del volumen
- [ ] Ensayo real de UI en escritorio y móvil
- [ ] Publicar release etiquetado y documentación de migración
- [ ] Solicitar inclusión en catálogo por defecto de HACS (opcional, sujeta a requisitos)

No se debe afirmar «instalación HACS de un clic» hasta que se hayan validado los puntos pendientes.
