# Alexa RTSP Bridge Pro — instalación guiada (vista previa)

Esta versión añade un **asistente de configuración web** y una **integración personalizada para HACS**. La aplicación RTSP–HLS sigue ejecutándose fuera de Home Assistant cuando se utiliza Home Assistant Container.

> Estado: vista previa de desarrollo. Las pruebas Python se ejecutaron localmente; falta validar la instalación de HACS dentro de una instancia real de Home Assistant y la actualización desde la beta de producción.

## Elegir instalación

| Sistema | Qué instalar | Qué NO hace HACS |
|---|---|---|
| Home Assistant Container (Docker) | Servicio Docker + integración HACS | HACS no crea contenedores ni configura AWS/Cloudflare |
| Home Assistant OS | App del repositorio + integración HACS opcional | La app instala el motor; HACS solamente conecta sus sensores |
| Docker sin Home Assistant | Servicio Docker y asistente web | No hace falta HACS |

## A. Probar el asistente sin tocar el servidor actual

Publica primero la rama `feature/hacs-wizard-preview-v0.3.0` usando el script del paquete. Esta opción crea un contenedor **independiente** con su propio volumen y nuevos puertos. No importa ni modifica cámaras existentes.

```bash
git clone --branch feature/hacs-wizard-preview-v0.3.0 https://github.com/RenanEspinar/Alexa-RTSP-Bridge.git
cd Alexa-RTSP-Bridge
bash scripts/start_wizard_preview.sh   # muestra qué hará
bash scripts/start_wizard_preview.sh --run
```

Abre `http://127.0.0.1:18199` desde el propio servidor, o establece un túnel SSH. En el primer acceso aparece el asistente de cuatro pasos. **Para acceder desde Internet**, usa una ruta HTTPS **protegida con Cloudflare Access** y verifica que una sesión anónima sea redirigida al login.

Para detener la vista previa sin borrar su configuración:

```bash
bash scripts/stop_wizard_preview.sh
```

No uses los puertos del preview para Alexa hasta terminar la configuración de seguridad y las pruebas.

## B. Instalar la integración con HACS (tras fusionarla en `main`)

1. Abre HACS → menú → **Custom repositories**.
2. Añade `https://github.com/RenanEspinar/Alexa-RTSP-Bridge` como tipo **Integration**.
3. Descarga **Alexa RTSP Bridge Pro**. HACS descarga de forma predeterminada la rama principal; el componente debe estar fusionado en `main` o disponible en un release compatible antes de usar este procedimiento.
4. Reinicia Home Assistant.
5. Ve a **Settings → Devices & Services → Add Integration → Alexa RTSP Bridge Pro**.
6. Introduce la URL del **panel administrativo accesible desde el servidor de Home Assistant**, por ejemplo `http://127.0.0.1:18099` *solo si Home Assistant comparte el espacio de red del host*. No uses el hostname remoto de Cloudflare Access: solicita autenticación de navegador y el conector no tiene una sesión.
7. Los sensores muestran **cámaras configuradas, transmisiones activas y tiempo activo del gateway**. Ninguna contraseña RTSP se importa a Home Assistant.

Comprueba la red de Home Assistant en Docker con:

```bash
docker inspect homeassistant --format '{{.HostConfig.NetworkMode}}'
```

Si aparece `host`, las direcciones `127.0.0.1:18099` del host suelen ser accesibles desde Home Assistant. Si aparece `bridge` u otra red, no abras el panel a Internet para resolverlo: hay que unir ambos servicios a una red Docker privada o usar un proxy autenticado y de alcance interno.

## C. Asistente dentro del panel

1. **Bienvenida:** explica cuáles son los componentes instalados y cuáles faltan.
2. **Cámaras:** utiliza el formulario habitual para añadir una cámara RTSP; los cambios se guardan en el volumen del gateway.
3. **Diagnóstico:** comprueba el códec y solicita un snapshot JPEG real.
4. **Alexa + HTTPS:** explica el túnel HLS, el mapeo de endpoint IDs y la Lambda de prueba. No modifica la cuenta Amazon automáticamente.

El asistente aparece automáticamente en un navegador nuevo cuando el gateway no tiene cámaras; puede abrirse de nuevo desde **Setup wizard**. La preferencia de mostrarlo se guarda solamente en el almacenamiento local del navegador.

## Seguridad

- Mantén **el panel administrativo** detrás de Home Assistant Ingress, SSH o Cloudflare Access.
- Publica **las listas HLS firmadas** en un hostname diferente, sin autenticación interactiva, y aplica controles de acceso compatibles con el relay de Alexa.
- Nunca publiques `cameras.json`, la clave HLS, las URLs RTSP ni `metadata.json` que contenga información privada.
- No cambies la Lambda de producción hasta terminar una prueba independiente completa.

## Limitaciones reconocidas

- HACS **no despliega Docker**. Una instalación completamente automática de extremo a extremo requeriría un mecanismo adicional para el sistema operativo y AWS.
- La integración HACS de este paquete es una implementación inicial y está **pendiente de validación funcional en Home Assistant real**.
- El wizard comprueba conexión RTSP y JPEG, pero no garantiza reproducción en Alexa.
- El gateway usa el API administrativo de la beta, con protección de acceso delegada a la red o a Cloudflare Access. No se debe exponer como servicio sin autenticación.
